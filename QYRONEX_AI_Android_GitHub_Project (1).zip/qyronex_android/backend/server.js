// Minimal example: OPENAI_API_KEY configured on server, never in APK.
// Add authentication, rate limits, abuse monitoring and durable storage before public deployment.
import http from 'node:http';
const PORT=Number(process.env.PORT||8080);
const allowed=process.env.ALLOWED_ORIGIN||'';
http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS') {res.writeHead(204,{'Access-Control-Allow-Origin':allowed,'Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS'});return res.end()}
  if(req.method!=='POST'||req.url!=='/api/chat'){res.writeHead(404);return res.end()}
  if(!process.env.OPENAI_API_KEY){res.writeHead(503,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'Server API key not configured'}))}
  let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>25000){res.writeHead(413);return res.end()}}
  try{
    const data=JSON.parse(raw);const prompt=String(data.message||'').slice(0,4000);
    if(!prompt){res.writeHead(400);return res.end()}
    const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:'gpt-4o-mini',messages:[{role:'system',content:'You are QYRONEX AI, a helpful Bengali-first assistant. Never claim to have performed phone actions you did not perform.'},{role:'user',content:prompt}]})});
    if(!response.ok){res.writeHead(502);return res.end(JSON.stringify({error:'AI provider error'}))}
    const body=await response.json();res.writeHead(200,{'Content-Type':'application/json','Access-Control-Allow-Origin':allowed});res.end(JSON.stringify({reply:body.choices?.[0]?.message?.content||''}));
  }catch(e){res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Invalid request'}))}
}).listen(PORT,()=>console.log('QYRONEX backend listening on',PORT));
