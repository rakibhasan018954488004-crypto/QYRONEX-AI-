# QYRONEX AI Android Starter

Creator: Noman Ahead. Screenshot-inspired navy/gold/cyan mobile home screen.

## Implemented now
- Responsive main page: QYRONEX header, transcript, animated CSS globe, Memory, Chat, Soul, Settings, STOP, Speaker, Voice, Headlines, Today Tasks.
- Chat history, notes, tasks, personality preferences stored locally in WebView storage.
- Chat POST to user-configured HTTPS backend endpoint (`{message,history,tone,language}` => `{reply}`), speech-to-text through Android recognizer, Android TTS, dialer intent, file text preview, optional browser camera preview (may require secure origin and Android WebChrome permission implementation).
- Multi-agent menu with honest status of planned modules; no simulated AI results or fabricated live news.

## Not implemented yet
- Fully operational AI backend/provider API keys, live headlines/search, vision AI, MediaProjection screen share, native app launcher, scheduled WorkManager automation, PDF parsing, native Room database, accessibility automation, Firebase sync, native camera permission bridge.
- This is a functional starter project, NOT a completed 15-agent assistant. No APK was built or tested in this environment.

## Security
- Do NOT store API keys in HTML/JS, localStorage, GitHub repo, or mobile APK. Put keys in server-side secret manager only.
- The sample WebView bridge loads only bundled trusted HTML. For production, use WebViewAssetLoader with an HTTPS appassets origin, strict origin-scoped bridge and CSP; do not load untrusted HTML into a JS-bridge-enabled WebView.
- Native camera preview requires additional runtime permission + WebChromeClient.onPermissionRequest, granted only after explicit user approval. Screen capture requires MediaProjection user consent. Accessibility requires user opt-in and policy compliance.
- The STOP button currently stops TTS and suppresses a pending response in UI; it does not abort an in-flight network request or background service.

## Build APK with GitHub Actions
1. Create a PRIVATE GitHub repository named `QYRONEX-AI`.
2. Upload the CONTENTS of this folder to the repository root (including `.github/workflows/build-apk.yml`). GitHub web uploader may hide dotfolders; use a Git client if necessary.
3. Open repository > Actions > Build QYRONEX Android APK > Run workflow. Or push to main.
4. When green, open the run > Artifacts > QYRONEX-AI-debug-apk. Unzip artifact to get `app-debug.apk`.
5. Android: allow install from this source only if you trust the build. Debug APK is for testing, not Play Store distribution.

Build is unverified here. GitHub runner uses system `gradle` which may have an incompatible version; if so replace with a Gradle 8.9 wrapper and run `./gradlew :app:assembleDebug`. Requires Java 17 and Android SDK 35.

## Backend API key slots
Use environment variables in a separate backend: OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, DEEPSEEK_API_KEY, GROQ_API_KEY, OPENROUTER_API_KEY, MISTRAL_API_KEY, ELEVENLABS_API_KEY, NEWS_API_KEY, SEARCH_API_KEY, FIREBASE_SERVICE_ACCOUNT. Never add actual values to GitHub source. The app only accepts a backend URL in Settings. Provider support must be implemented and tested on the backend.

## Optional online backend starter
`backend/server.js` demonstrates a server-side OpenAI API call. Copy the names in `backend/.env.example` into your hosting provider's secret/environment settings (not into the repository), and set `OPENAI_API_KEY`. Run with Node 20+ (`node backend/server.js`). Use an HTTPS reverse proxy / hosted HTTPS endpoint and configure `https://YOUR-HOST/api/chat` in app Settings. The server is intentionally not production-ready: add authentication, request limits, CORS origin policy appropriate to the Android WebView, logging/privacy controls, and provider error handling. Other listed provider slots are placeholders, not implemented integrations.
