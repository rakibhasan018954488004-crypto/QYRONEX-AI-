package com.qyronex.ai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.widget.Toast
import java.util.Locale
import org.json.JSONObject

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private val voiceRequest = 701
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.toString() != "https://appassets.androidplatform.net/assets/index.html"
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "QyronexNative")
        setContentView(web)
        // Only bundled, trusted HTML is loaded; never load external pages in this WebView.
        web.loadUrl("file:///android_asset/index.html")
    }
    inner class Bridge {
        @JavascriptInterface fun dial(number: String) = runOnUiThread {
            val cleaned = number.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
            if (cleaned.isNotBlank()) startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(cleaned))))
        }
        @JavascriptInterface fun speak(text: String) = runOnUiThread { tts?.speak(text.take(1500), TextToSpeech.QUEUE_FLUSH, null, "qyronex") }
        @JavascriptInterface fun stopSpeaking() = runOnUiThread { tts?.stop() }
        @JavascriptInterface fun listen() = runOnUiThread {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                startActivityForResult(intent, voiceRequest)
            } catch (_: Exception) { Toast.makeText(this@MainActivity,"Speech recognition unavailable",Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface fun share(text: String) = runOnUiThread {
            val intent = Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT, text.take(10000)) }
            startActivity(Intent.createChooser(intent,"Share QYRONEX"))
        }
        @JavascriptInterface fun openSettings() = runOnUiThread {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "BD") }
    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: ""
            val encoded = JSONObject.quote(phrase)
            web.evaluateJavascript("window.onNativeSpeech($encoded)", null)
        }
    }
    override fun onDestroy() { tts?.shutdown(); web.removeJavascriptInterface("QyronexNative"); web.destroy(); super.onDestroy() }
}
